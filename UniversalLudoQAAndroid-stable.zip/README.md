# Universal Ludo QA — Android stable build

This is a lightweight native Android controller shell designed for cloud APK builds.

## Build target
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- JDK: 17
- compileSdk/targetSdk: 35
- minSdk: 26
- No third-party runtime dependencies

Android documents AGP 8.6 as compatible with Gradle 8.7, JDK 17, and API 35.

## What is included
- Native Android dashboard
- Accessibility Service declaration
- Window/content/click event observation
- Gesture tap helper
- No hidden interaction

## Scope
Universal visual board/dice recognition and per-game rules remain separate QA modules. Different Play Store Ludo games can render their boards differently, so compatibility requires an authorized game profile/calibration layer.
