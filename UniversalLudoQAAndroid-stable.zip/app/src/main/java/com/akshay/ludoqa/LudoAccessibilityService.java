package com.akshay.ludoqa;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

public final class LudoAccessibilityService extends AccessibilityService {
    private static volatile boolean observing = false;

    public static void setObserving(boolean value) {
        observing = value;
    }

    public static boolean isObserving() {
        return observing;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!observing || event == null) {
            return;
        }
        Log.i("LudoQA", "event=" + event.getEventType()
                + " package=" + event.getPackageName()
                + " class=" + event.getClassName());
    }

    @Override
    public void onInterrupt() {
        observing = false;
    }

    public boolean tapAt(float x, float y, long durationMs) {
        if (durationMs < 1L) {
            durationMs = 1L;
        }
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0L, durationMs))
                .build();
        return dispatchGesture(gesture, null, null);
    }
}
