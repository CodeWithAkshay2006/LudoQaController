package com.akshay.ludoqa;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 24);
        root.setBackgroundColor(Color.rgb(15, 23, 42));

        TextView title = textView("Universal Ludo QA", 27, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = textView("Android UI testing controller", 14, Color.LTGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 24);
        root.addView(subtitle);

        status = textView("Ready · Accessibility service disabled", 16, Color.WHITE, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(12, 20, 12, 20);
        root.addView(status);

        root.addView(actionButton("Enable QA accessibility", () ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        root.addView(actionButton("Open installed-app settings", () ->
                startActivity(new Intent(Settings.ACTION_SETTINGS))));

        root.addView(actionButton("Start observation", () -> {
            LudoAccessibilityService.setObserving(true);
            status.setText("Observation ON · Open the authorized target game");
        }));

        root.addView(actionButton("Stop testing", () -> {
            LudoAccessibilityService.setObserving(false);
            status.setText("Stopped");
        }));

        TextView note = textView(
                "This APK is an authorized Android QA controller shell. " +
                "Board/dice vision, per-game calibration and move verification are separate modules. " +
                "Use only with apps and accounts you are authorized to test.",
                13, Color.LTGRAY, false);
        note.setPadding(4, 24, 4, 0);
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private TextView textView(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) {
            view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        }
        view.setPadding(0, 12, 0, 8);
        return view;
    }

    private Button actionButton(String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 10;
        button.setLayoutParams(lp);
        return button;
    }
}
