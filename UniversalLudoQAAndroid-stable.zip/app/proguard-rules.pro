# Universal Ludo QA: no custom shrinking rules required for the debug build.
