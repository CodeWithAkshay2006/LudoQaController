package com.akshay.ludoqa

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log

class LudoAccessibilityService : AccessibilityService() {
    companion object { @Volatile var observing: Boolean = false }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!observing || event == null) return
        Log.i("LudoQA", "event=${event.eventType} package=${event.packageName} class=${event.className}")
        // Intentionally observe-only: automated taps require per-game calibration and explicit test setup.
    }
    override fun onInterrupt() { observing = false }
    fun tapAt(x: Float, y: Float, durationMs: Long = 80L) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        dispatchGesture(gesture, null, null)
    }
}
