package com.akshay.ludoqa

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 24); setBackgroundColor(Color.rgb(15,23,42)) }
        val title = TextView(this).apply { text = "Universal Ludo QA"; textSize = 27f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,12,0,8) }
        val subtitle = TextView(this).apply { text = "Android UI testing controller"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0,0,0,24) }
        status = TextView(this).apply { text = "Ready · No game selected"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(12,20,12,20) }
        root.addView(title); root.addView(subtitle); root.addView(status)
        root.addView(actionButton("Enable QA accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(actionButton("Choose game to test") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        root.addView(actionButton("Start observation") { LudoAccessibilityService.observing = true; status.text = "Observation enabled · Open the target game" })
        root.addView(actionButton("Stop testing") { LudoAccessibilityService.observing = false; status.text = "Stopped" })
        val note = TextView(this).apply { text = "This build provides the Android controller shell and accessibility event observation. Game-specific board calibration and vision-based move verification are required for each supported Ludo app. Use only with apps and accounts you are authorized to test."; textSize = 13f; setTextColor(Color.LTGRAY); setPadding(4,24,4,0) }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 } }
}
