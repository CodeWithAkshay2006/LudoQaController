# Universal Ludo QA — Android project

Android Studio project (Kotlin) for an extensible, user-authorized Ludo QA controller.

## Build
1. Open this folder in Android Studio with JDK 17 and Android SDK Platform 35 installed.
2. Allow Gradle sync to download the Android Gradle Plugin and Kotlin plugin.
3. Build > Build APK(s). The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
4. Install on a test phone and explicitly enable the app's accessibility service in Android Settings.

## Current implementation
- Native Android dashboard with observe/start/stop controls.
- Accessibility service declaration and event observation.
- Gesture tap helper for future calibrated test actions.
- No hidden interaction or automatic wagering/competitive play.

## Important scope
This is an Android Studio source project, not a prebuilt or device-verified APK. It does not yet provide universal vision-based board/dice recognition, game-specific rules, or autonomous move verification. Each target app requires authorized testing, calibration, and validation. Accessibility events alone cannot guarantee compatibility with arbitrary Play Store games.
